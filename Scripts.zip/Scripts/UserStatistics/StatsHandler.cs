using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StatsHandler : MonoBehaviour
{

    //Kills
    public int pistolKills;
    public int arKills;

    //Weapon Levels

    public int pistolLevel;
    public int arLevel;

    //Attachments unlocked
    public bool guardianReceiver;
    public bool guardianBolt;
    public bool guardianBarrel;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
